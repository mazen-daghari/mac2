import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, GroupAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
import xacro

def generate_launch_description():
    robotXacroName = 'differential_drive_robot'
    package_name = 'mazen'
    modelFileRelativePath = 'model/ackermann1.urdf.xacro'
    worldFileRelativePath = 'worlds/empty_world.world'

    pathModelFile = os.path.join(get_package_share_directory(package_name), modelFileRelativePath)
    pathWorldFile = os.path.join(get_package_share_directory(package_name), worldFileRelativePath)

    # Configurations and files
    robot_description = xacro.process_file(pathModelFile).toxml()
    rviz_config_file = os.path.join(get_package_share_directory(package_name), 'rviz', 'robot.rviz')
    nav_params = os.path.join(get_package_share_directory(package_name), 'config', 'nav_params.yaml')
    twist_mux_params = os.path.join(get_package_share_directory(package_name), 'config', 'twist_mux_params.yaml')
    gazebo_params_file = os.path.join(get_package_share_directory(package_name), 'config', 'gazebo_params.yaml')

    # Launch configuration variables
    world = LaunchConfiguration('world')
    headless = LaunchConfiguration('headless')
    rviz = LaunchConfiguration('rviz')
    slam = LaunchConfiguration('slam')
    nav = LaunchConfiguration('nav')

    # Declare launch arguments
    declare_world = DeclareLaunchArgument(
        name='world', default_value=pathWorldFile,
        description='Full path to the world model file to load')

    declare_headless = DeclareLaunchArgument(
        'headless', default_value='False',
        description='Decides if the simulation is visualized')

    declare_rviz = DeclareLaunchArgument(
        name='rviz', default_value='True',
        description='Opens rviz if set to True')

    declare_slam = DeclareLaunchArgument(
        name='slam', default_value='True',
        description='Activates simultaneous localization and mapping')

    declare_nav = DeclareLaunchArgument(
        name='nav', default_value='True',
        description='Activates the navigation stack')

    # Gazebo launch
    gazeboLaunch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={'world': pathWorldFile}.items()
    )

    # RViz launch
    rviz2 = GroupAction(
        condition=IfCondition(rviz),
        actions=[Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_file],
            parameters=[{'use_sim_time': True}],
            output='screen',
            remappings=[
                ('/map', 'map'),
                ('/tf', 'tf'),
                ('/tf_static', 'tf_static'),
                ('/goal_pose', 'goal_pose'),
                ('/clicked_point', 'clicked_point'),
                ('/initialpose', 'initialpose')
            ])]
    )

    # SLAM launch
    slam_node = GroupAction(
        condition=IfCondition(slam),
        actions=[IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                os.path.join(get_package_share_directory(package_name), 'launch', 'slam.launch.py')
            ]),
            launch_arguments={'use_sim_time': 'true'}.items())]
    )

    # Navigation launch
    nav_node = GroupAction(
        condition=IfCondition(nav),
        actions=[IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                os.path.join(get_package_share_directory(package_name), 'launch', 'nav.launch.py')
            ]),
            launch_arguments={'use_sim_time': 'true', 'params_file': nav_params}.items())]
    )

    # Twist Mux launch
    twist_mux = Node(
        package="twist_mux",
        executable="twist_mux",
        parameters=[twist_mux_params, {'use_sim_time': True}],
        remappings=[('/cmd_vel_out', '/cmd_vel')]
    )

    # Robot State Publisher
    nodeRobotStatePublisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description, 'use_sim_time': True}]
    )

    # Spawn model in Gazebo
    spawnModelNode = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', robotXacroName],
        output='screen'
    )

    # Teleop keyboard control
    teleopNode = Node(
        package='teleop_twist_keyboard',
        executable='teleop_twist_keyboard',
        name='teleop_twist_keyboard',
        prefix='gnome-terminal --',
        output='screen',
        remappings=[('/cmd_vel', '/cmd_vel')]
    )

    # Build launch description
    launchDescriptionObject = LaunchDescription()

    # Add all launch arguments
    launchDescriptionObject.add_action(declare_world)
    launchDescriptionObject.add_action(declare_headless)
    launchDescriptionObject.add_action(declare_rviz)
    launchDescriptionObject.add_action(declare_slam)
    launchDescriptionObject.add_action(declare_nav)

    # Add nodes
    launchDescriptionObject.add_action(gazeboLaunch)
    launchDescriptionObject.add_action(spawnModelNode)
    launchDescriptionObject.add_action(nodeRobotStatePublisher)
    launchDescriptionObject.add_action(twist_mux)
    launchDescriptionObject.add_action(rviz2)
    launchDescriptionObject.add_action(slam_node)
    launchDescriptionObject.add_action(nav_node)
    

    return launchDescriptionObject
